<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>General Ledger</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-6">
        <div class="bg-white rounded-lg shadow-md p-6">
            <h1 class="text-3xl font-bold text-gray-800 mb-6">General Ledger</h1>
            
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Account</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Receipt</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Debit</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Credit</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php 
                        $totalDebit = 0;
                        $totalCredit = 0;
                        foreach ($rows as $row): 
                            $totalDebit += floatval($row['debit']);
                            $totalCredit += floatval($row['credit']);
                        ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= htmlspecialchars($row['date_of_payment']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <a href="?action=ledger&acct_id=<?= $row['acct_id'] ?>" class="text-blue-600 hover:text-blue-800">
                                    <?= htmlspecialchars($row['acct_code']) ?> - <?= htmlspecialchars($row['acct_alias'] ?: $row['acct_name']) ?>
                                </a>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900">
                                <?= htmlspecialchars($row['transaction_desc']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <?= htmlspecialchars($row['receipt_no']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600 font-medium">
                                <?= $row['debit'] > 0 ? number_format($row['debit'], 2) : '' ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-red-600 font-medium">
                                <?= $row['credit'] > 0 ? number_format($row['credit'], 2) : '' ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="bg-gray-50">
                        <tr class="font-bold">
                            <td colspan="4" class="px-6 py-4 text-right text-sm text-gray-900">Page Totals:</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600">
                                <?= number_format($totalDebit, 2) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-red-600">
                                <?= number_format($totalCredit, 2) ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <?php if ($totalRows > $perPage): ?>
            <div class="mt-4 flex justify-between items-center">
                <div class="text-sm text-gray-700">
                    Showing page <?= $page ?> of <?= ceil($totalRows / $perPage) ?>
                    (<?= $totalRows ?> total transactions)
                </div>
                <div class="flex space-x-2">
                    <?php if ($page > 1): ?>
                    <a href="?action=gl&page=<?= $page - 1 ?>" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Previous</a>
                    <?php endif; ?>
                    <?php if ($page * $perPage < $totalRows): ?>
                    <a href="?action=gl&page=<?= $page + 1 ?>" class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Next</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
