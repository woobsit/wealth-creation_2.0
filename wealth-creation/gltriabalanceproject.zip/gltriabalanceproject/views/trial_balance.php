<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trial Balance</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="container mx-auto px-4 py-6">
        <div class="bg-white rounded-lg shadow-md p-6">
            <h1 class="text-3xl font-bold text-gray-800 mb-6">Trial Balance</h1>
            
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Account Code</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Account Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Debit</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Credit</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php 
                        $totalDebit = 0;
                        $totalCredit = 0;
                        foreach ($rows as $row): 
                            $totalDebit += floatval($row['total_debit']);
                            $totalCredit += floatval($row['total_credit']);
                        ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                <?= htmlspecialchars($row['acct_code']) ?>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-900">
                                <?= htmlspecialchars($row['acct_alias'] ?: $row['acct_name']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                <?= htmlspecialchars($row['acct_type']) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                <?= htmlspecialchars($row['acct_class'] ?: '-') ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-green-600 font-medium">
                                <?= floatval($row['total_debit']) > 0 ? number_format($row['total_debit'], 2) : '-' ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-red-600 font-medium">
                                <?= floatval($row['total_credit']) > 0 ? number_format($row['total_credit'], 2) : '-' ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot class="bg-gray-100 font-bold border-t-2">
                        <tr>
                            <td colspan="4" class="px-6 py-4 text-sm text-gray-900 text-right">TOTALS:</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-green-700">
                                <?= number_format($totalDebit, 2) ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-right text-red-700">
                                <?= number_format($totalCredit, 2) ?>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>

            <?php if (abs($totalDebit - $totalCredit) < 0.01): ?>
            <div class="mt-4 p-4 bg-green-50 border border-green-200 rounded text-green-700">
                ✓ Trial Balance is in balance (Debit = Credit = <?= number_format($totalDebit, 2) ?>)
            </div>
            <?php else: ?>
            <div class="mt-4 p-4 bg-red-50 border border-red-200 rounded text-red-700">
                ✗ Trial Balance is NOT in balance (Difference: <?= number_format(abs($totalDebit - $totalCredit), 2) ?>)
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
